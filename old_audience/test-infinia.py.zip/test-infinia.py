import requests
import json
import re
import mysql.connector
import pandas as pd
import numpy as np
import logging as log
from datetime import datetime, timedelta
from datetime import date
import sys

from sqlalchemy import create_engine
from datetime import datetime, timedelta

#Authorization
auth = "Bearer 8257e2bd47435d424a6e13580a54a12d";

url_reservation_by_display_unit= 'https://api-sandbox.broadsign.com:10889/rest/reservation/v20/by_du_folder?domain_id=266174&current_only=false';


url_reservation_container=url_reservation_by_display_unit+"&container_ids=270379"

#print(url_reservation_container)
s=requests.get(url_reservation_container,headers={'Accept': 'application/json','Authorization': auth})
data=json.loads(s.text)

print(data)